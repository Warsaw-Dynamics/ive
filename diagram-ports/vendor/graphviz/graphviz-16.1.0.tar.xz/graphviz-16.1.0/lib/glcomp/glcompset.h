/*************************************************************************
 * Copyright (c) 2011 AT&T Intellectual Property 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/org/documents/epl-2.0/EPL-2.0.html
 *
 * Contributors: Details at https://graphviz.org
 *************************************************************************/

/*Open GL basic component set
  includes glPanel,glCompButton,glCompCustomButton,clCompLabel,glCompStyle
*/

#pragma once

#include <glcomp/glcompfont.h>
#include <glcomp/glcomptextpng.h>

#ifdef __cplusplus
extern "C" {
#endif

void glCompInitCommon(glCompObj *childObj, glCompObj *parentObj, float x,
                      float y);
    void glCompEmptyCommon(glCompCommon * c);
    extern glCompSet *glCompSetNew(int w, int h);
    extern void glCompSetDraw(glCompSet *s);
    extern void glcompsetUpdateBorder(glCompSet * s, int w, int h);
    extern void glCompDrawBegin(void);
    extern void glCompDrawEnd(void);
    extern void glCompSetAddObj(glCompSet * s, glCompObj * obj);

#ifdef __cplusplus
}
#endif
