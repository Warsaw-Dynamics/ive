/*************************************************************************
 * Copyright (c) 2011 AT&T Intellectual Property 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/org/documents/epl-2.0/EPL-2.0.html
 *
 * Contributors: Details at https://graphviz.org
 *************************************************************************/

#pragma once

#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <glcomp/opengl.h>
#include <glcomp/glcompdefs.h>
#include <GL/glut.h>

#ifdef __cplusplus
extern "C" {
#endif

    void glprintfglut(void *font, float xpos, float ypos, float zpos, char *bf);

glCompFont glNewFont(glCompSet *s, const char *text, glCompColor *c,
                     char *fontdesc, int fs, bool is2D);
glCompFont glNewFontFromParent(glCompObj *o, const char *text);
    void glDeleteFont(glCompFont * f);
void glCompDrawText(glCompFont f, double x, double y);
void glCompRenderText(glCompFont f, glCompObj *parentObj);
void glCompDrawText3D(glCompFont f, double x, double y, double z, double w,
                      double h);

#ifdef __cplusplus
}
#endif
