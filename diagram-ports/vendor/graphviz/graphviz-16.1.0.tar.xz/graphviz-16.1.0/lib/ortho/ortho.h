/*************************************************************************
 * Copyright (c) 2011 AT&T Intellectual Property
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/org/documents/epl-2.0/EPL-2.0.html
 *
 * Contributors: Details at https://graphviz.org
 *************************************************************************/

#pragma once

#include <render.h>
#include <stdbool.h>

#ifdef GVDLL
#ifdef GVC_EXPORTS
#define ORTHO_API __declspec(dllexport)
#else
#define ORTHO_API __declspec(dllimport)
#endif
#endif

#ifndef ORTHO_API
#define ORTHO_API /* nothing */
#endif

ORTHO_API int orthoEdges(Agraph_t *g, bool useLbls);
