/// @file
/// @ingroup common_utils
/*************************************************************************
 * Copyright (c) 2011 AT&T Intellectual Property
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/org/documents/epl-2.0/EPL-2.0.html
 *
 * Contributors: Details at https://graphviz.org
 *************************************************************************/

#pragma once

#include <common/htmltable.h>
#include <util/agxbuf.h>

#ifdef __cplusplus
extern "C" {
#endif

union HTMLSTYPE;
typedef struct htmlparserstate_s htmlparserstate_t;
typedef struct htmlscan_s htmlscan_t;

int initHTMLlexer(htmlscan_t *, char *, agxbuf *, htmlenv_t *);
int htmllex(union HTMLSTYPE *, htmlscan_t *);
unsigned long htmllineno(htmlscan_t *);
int clearHTMLlexer(htmlscan_t *);
void htmlerror(htmlscan_t *, const char *);

#ifdef __cplusplus
}
#endif
